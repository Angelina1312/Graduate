document.getElementById('korzina').onclick = function() { 
  alert("Товар успешно добавлен в корзину!"); 
}