// товар 1
function mOver(obj) {
  document.getElementById('imag').src = "img/akadem_shapka/mantiya_magistra006-800x800.jpg";
}

function mOut(obj) {
 document.getElementById('imag').src = "img/akadem_shapka/mantiya_magistra004-800x800.jpg";
}

// товар 3
function mOver1(obj) {
  document.getElementById('imag3').src = "img/komplekt_magistra/mantiya_magistra_deluxe2-800x800.jpg";
}

function mOut1(obj) {
 document.getElementById('imag3').src = "img/komplekt_magistra/mantiya_magistra_deluxe-800x800.jpg";
}

// товар 4
function mOver2(obj) {
  document.getElementById('imag4').src = "img/mantia_i_shapka/мантия-выпускника-3-800x800.jpg";
}

function mOut2(obj) {
 document.getElementById('imag4').src = "img/mantia_i_shapka/мантия-черная-800x800.jpg";
}

// товар 6
function mOver3(obj) {
  document.getElementById('imag6').src = "img/det_sinyaya/мантия-и-шапочка-детская-002-800x800.jpg";
}

function mOut3(obj) {
 document.getElementById('imag6').src = "img/det_sinyaya/мантия-и-шапочка-детская-001-800x800.jpg";
}

// товар 7
function mOver4(obj) {
  document.getElementById('imag7').src = "img/barh_shapka/shapochka_barhat_bordo2-800x800.jpg";
}

function mOut4(obj) {
 document.getElementById('imag7').src = "img/barh_shapka/shapochka_barhat_bordo1-800x800.jpg";
}

// товар 9
function mOver5(obj) {
  document.getElementById('imag9').src = "img/akadem_belaya/mantiya_magistra014-800x800.jpg";
}

function mOut5(obj) {
 document.getElementById('imag9').src = "img/akadem_belaya/ar-bh-mt-012_0_4-800x800.jpg";
}

// товар 10
function mOver6(obj) {
  document.getElementById('imag10').src = "img/akadem_bordovaya/konfederatka_bordo-800x800.jpg";
}

function mOut6(obj) {
 document.getElementById('imag10').src = "img/akadem_bordovaya/gs-cgam-mrn-800x800.jpg";
}

// товар 11
function mOver7(obj) {
  document.getElementById('imag11').src = "img/akadem_zholtaya/mantiya_magistra022-800x800.jpg";
}

function mOut7(obj) {
 document.getElementById('imag11').src = "img/akadem_zholtaya/mantiya_magistra021-800x800.jpg";
}

// товар 14
function mOver8(obj) {
  document.getElementById('imag14').src = "img/akadem_orange/mantiya_magistra045-800x800.jpg";
}

function mOut8(obj) {
 document.getElementById('imag14').src = "img/akadem_orange/mantiya_magistra043-800x800.jpg";
}

// товар 15
function mOver9(obj) {
  document.getElementById('imag15').src = "img/akadem_sv_ser/mantiya_magistra035-800x800.jpg";
}

function mOut9(obj) {
 document.getElementById('imag15').src = "img/akadem_sv_ser/mantiya_magistra033-800x800.jpg";
}

// товар 16
function mOver10(obj) {
  document.getElementById('imag16').src = "img/akadem_sinyaya/мантия-выпускника-4-800x800.jpg";
}

function mOut10(obj) {
 document.getElementById('imag16').src = "img/akadem_sinyaya/adult_cap_and_gown_canstock_base-800x800.jpg";
}

// товар 17
function mOver11(obj) {
  document.getElementById('imag17').src = "img/akadem_tem_sin/мантия-выпускника-7-800x800.jpg";
}

function mOut11(obj) {
 document.getElementById('imag17').src = "img/akadem_tem_sin/мантия-и-шапочка-выпускника-темно-синие-800x800.jpg";
}

// товар 19
function mOver12(obj) {
  document.getElementById('imag19').src = "img/galstuk/galstuk_fioletovij-goggles-800x800.jpg";
}

function mOut12(obj) {
 document.getElementById('imag19').src = "img/galstuk/galstuk-zolotoy-800x800.jpg";
}

// товар 20
function mOver13(obj) {
  document.getElementById('imag20').src = "img/kapushon/galstuk-kapushon-siniy-800x800.jpg";
}

function mOut13(obj) {
 document.getElementById('imag20').src = "img/kapushon/galstuk-kapushon-gold-800x800.jpg";
}

// товар 21
function mOver14(obj) {
  document.getElementById('imag21').src = "img/man_i_shap_golub/konfederatka_blue-800x800.jpg";
}

function mOut14(obj) {
 document.getElementById('imag21').src = "img/man_i_shap_golub/gs-cgam-sky-800x800.jpg";
}