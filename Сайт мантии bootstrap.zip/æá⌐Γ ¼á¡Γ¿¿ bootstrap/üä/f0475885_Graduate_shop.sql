-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 10.0.2.30
-- Время создания: Фев 10 2021 г., 17:06
-- Версия сервера: 5.7.31-34
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `f0475885_Graduate_shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `Order_num` int(11) NOT NULL,
  `ID_prod` int(11) NOT NULL,
  `ID_cust` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `opt`
--

CREATE TABLE `opt` (
  `ID_cust` int(11) NOT NULL,
  `Name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Name_firm` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ID_prod` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `ID_cust` int(11) NOT NULL,
  `Name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Height` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Name_prod` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Order_num` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `ID_prod` int(11) NOT NULL,
  `Img` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Name_prod` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Availability` tinyint(1) DEFAULT NULL,
  `Price` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Description` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ID_cust` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`ID_prod`, `Img`, `Name_prod`, `Availability`, `Price`, `Description`, `ID_cust`) VALUES
(1, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая шапочка выпускника, всех цветов', 1, '250 р.', 'Квадратная шапочка выпускника с кисточкой (шапочка магистра, бакалавра, специалиста) сшита из габардина. В комплект входит: шапочка, кисточка, упаковка. Шапочка конфедератка универсального размера, благодаря резинки, вшитую в нижнюю часть шапочки. Все шапочки идут в комплекте с кистью, каждая шапочка упакована в индивидуальный пакет. Цвет кисточки - золотой или любой на ваш выбор (белый, красный, синий, зеленый, черный, бордовый, бежевый, голубой, фиолетовый). Шапочка выпускника имеет превосходный вид и качественный материал. Шапочка мужская и женская, идеально подойдет для взрослых и детей. Купить квадратную шапку выпускника любого цвета и размера.\r\nПроизводство - Россия. Если вам нужна шапочка выпускника на один день, то у нас есть услуга проката. Стоимость аренды одной шапочки 100 руб / 5 суток. При заказе от 20 шапочек - бесплатная доставка и возврат.\r\nЦвета шапочек: черный, фиолетовый, синий, зеленый, белый, желтый, красный, бордовый, серый, темно-синий, оранжевый, голубой, коричн', 1),
(2, 'img/glav_photo/detskaya-manija-i-shapochka-black-800x800.jpg', 'Детская мантия и квадратная шапочка выпускника', 1, '700 р.', 'Детская мантия и шапочка черного цвета, облегченная\r\n\r\nШапочка конфедератка универсального размера, ', 2),
(3, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Комплект магистра', 1, '1550 р.', 'Мантия, шапочка и капюшон магистра сшиты из габардина, внутри капюшона атласная подладка.\r\n\r\nШапочка', 3),
(4, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Мантия и шапочка выпускника, черная', 1, '1200 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nШапочка конфедератка универ', 4),
(5, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Мантия и шапочка детская, облегченная', 1, '3250 р.', 'Детская мантия и шапочка бордового цвета, облегченная\r\n\r\nШапочка конфедератка универсального размера', 5),
(6, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Мантия и шапочка детская, облегченная', 1, '4250 р.', 'Детская мантия и шапочка синего цвета, облегченная\r\n\r\nШапочка конфедератка универсального размера, б', 6),
(7, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Шапочка бархатная', 1, '1000 р.', 'Шапочка сшита из плотного бархата, внутри шапочки черная подкладка.\r\n\r\nМожно заказать любой цвет шап', 7),
(8, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Шапочка выпускника черная, блестящая', 1, '250 р.', 'Шапочка атласная, белстящая. Цвет черный\r\n\r\nМожно заказать любой цвет шапочки (белый, красный, синий', 8),
(9, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая одежда белая', 1, '1200 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nШапочка конфедератка универ', 9),
(10, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая одежда бордовая', 1, '1290 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nШапочка конфедератка универ', 10),
(11, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая одежда желтая', 1, '1090 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nШапочка конфедератка универ', 11),
(12, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая одежда зеленая', 1, '1390 р.', 'Квадратная шапочка выпускника с кисточкой (шапочка магистра, бакалавра, специалиста) сшита из габард', 12),
(13, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая одежда красная', 1, '1190 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nШапочка конфедератка универ', 13),
(14, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая одежда оранжевая', 1, '1290 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nШапочка конфедератка универ', 14),
(15, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая одежда светло-серая', 1, '1200 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nШапочка конфедератка универ', 15),
(16, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая одежда синяя', 1, '1290 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nШапочка конфедератка универ', 16),
(17, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая одежда темно-синяя', 1, '1290 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nШапочка конфедератка универ', 17),
(18, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Академическая одежда фиолетовая', 1, '1390 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nШапочка конфедератка универ', 18),
(19, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Галстук всех цветов', 1, '150 р.', 'Галстук - это прекрасное дополнение к мантии выпускника. Если не нашли нужного цвета или ткани - соо', 19),
(20, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Галстук-капюшон всех цветов', 1, '200 р.', 'Накидка специалиста - это прекрасное дополнение к мантии выпускника. Накидки у магистра и бакалавра ', 20),
(21, 'img/glav_photo/mantiya_magistra004-800x800.jpg', 'Мантия и шапочка выпускника, голубые', 1, '1990 р.', 'Мантия и шапочка магистра, бакалавра, специалиста сшиты из габардина.\r\n\r\nапочка конфедератка универс', 21);

-- --------------------------------------------------------

--
-- Структура таблицы `rent`
--

CREATE TABLE `rent` (
  `Rent_num` int(11) NOT NULL,
  `Name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Height` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`Order_num`);

--
-- Индексы таблицы `opt`
--
ALTER TABLE `opt`
  ADD PRIMARY KEY (`ID_cust`),
  ADD UNIQUE KEY `ID_prod` (`ID_prod`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ID_cust`),
  ADD UNIQUE KEY `ID_prod` (`Order_num`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ID_prod`),
  ADD UNIQUE KEY `ID_cust` (`ID_cust`);

--
-- Индексы таблицы `rent`
--
ALTER TABLE `rent`
  ADD PRIMARY KEY (`Rent_num`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `Order_num` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `opt`
--
ALTER TABLE `opt`
  MODIFY `ID_cust` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `ID_cust` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `ID_prod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `rent`
--
ALTER TABLE `rent`
  MODIFY `Rent_num` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
